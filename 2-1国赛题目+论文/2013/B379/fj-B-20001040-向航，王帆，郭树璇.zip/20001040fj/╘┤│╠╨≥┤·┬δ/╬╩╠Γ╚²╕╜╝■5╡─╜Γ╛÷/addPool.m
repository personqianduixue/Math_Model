function [ pool ] = addPool( picturePool,number )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
           pool=[picturePool number];
end

